import openpyxl
from io import StringIO
import tokenize
import re

##For the Equation , put all the variables and operators in list
def mysplit(FileLine):
    List    = filter(None,([token[1] for token in tokenize.generate_tokens(StringIO(unicode(FileLine.replace(" ",""))).readline) if token[1]]))
    return [str(Ind) for Ind in List]
            
##Remove comments from the selected line([+-=/;*()])
def RemoveComments(FileLine):
    Index   = FileLine.find('//')
    FileLine= FileLine[:Index-1]
    return FileLine

##Precedence of the operators
Prec    = {'('      : 13,
           ')'      : 13,
           '*'      : 12,
           '/'      : 12,
           '%'      : 12,
           '+'      : 11,
           '-'      : 11,
           '<<'     : 10,
           '>>'     : 10,
           '>'      : 9,
           '<'      : 9,
           '<='     : 9,
           '>='     : 9,
           '=='     : 8,
           '!='     : 8,
           '&'      : 7,
           '^'      : 6,
           '|'      : 5,
           '&&'     : 4,
           '||'     : 3,
           '?'      : 2,
           '='      : 1,
           '*='     : 1,
           '/='     : 1,
           '+='     : 1,
           '-='     : 1,
           '<<='    : 1,
           '>>='    : 1,
           '&='     : 1,
           '^='     : 1,
           '|='     : 1,
           ','      : 0,
           }


wb = openpyxl.load_workbook('Example_Violations.xlsx')
sheets  = wb.get_sheet_names()
sheet   = wb.get_sheet_by_name('Sheet1')
ROW     = 1
while True:
    ROW += 1
    LineNo      = sheet.cell(row = ROW,column = 2).value
    if LineNo is None:
        break
    LineNo      = int(LineNo)
    print 'Line no. is ',LineNo

    FileName    = sheet.cell(row = ROW,column = 1).value
    FileName    = FileName.encode("ascii")
    print 'File Name is ',FileName

    Violation   = float(sheet.cell(row = ROW,column = 3).value)
    print 'Violation no. is ',Violation

    if( Violation   == 12.1):
        with open('%s.txt' %FileName,'r+') as File:
            FileLines   = File.readlines()
            FileLine    = FileLines[LineNo - 1]
            print '1',FileLine
            
            FileLine    = RemoveComments(FileLine)
            print '2',FileLine
            List        = mysplit(FileLine)
            print '3',List
