import openpyxl
from io import StringIO
import tokenize
import re

def mysplit(FileLine):
    return filter(None,(re.split('([(+-=/;*)])',FileLine.replace(" ",""))))
def RemoveComments(FileLine):
    Index   = FileLine.find('//')
    FileLine= FileLine[:Index]
    return FileLine
wb = openpyxl.load_workbook('Example_Violations.xlsx')
sheets  = wb.get_sheet_names()
sheet   = wb.get_sheet_by_name('Sheet1')
ROW     = 1
while True:
    ROW += 1
    LineNo      = sheet.cell(row = ROW,column = 2).value
    if LineNo is None:
        break
    LineNo      = int(LineNo)
    print 'Line no. is ',LineNo

    FileName    = sheet.cell(row = ROW,column = 1).value
    FileName    = FileName.encode("ascii")
    print 'File Name is ',FileName

    Violation   = float(sheet.cell(row = ROW,column = 3).value)
    print 'Violation no. is ',Violation

    if( Violation   == 12.1):
        with open('%s.txt' %FileName,'r+') as File:
            FileLines   = File.readlines()
            FileLine    = FileLines[LineNo - 1]
            print '1',FileLine
            FileLine    = RemoveComments(FileLine)
            print '2',FileLine
            List        = mysplit(FileLine)
            print '3',List
